
import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'services/socket_service.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final socketService = SocketService();
  MyApp({super.key}) {
    // default local server for emulator
    socketService.connect('http://10.0.2.2:3000');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KECGrub',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LoginPage(),
    );
  }
}
