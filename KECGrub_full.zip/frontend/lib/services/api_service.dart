
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  final String baseUrl;
  ApiService(this.baseUrl);

  Future<List<dynamic>> fetchMenu() async {
    final res = await http.get(Uri.parse('$baseUrl/api/menu'));
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('Failed to load menu');
  }

  Future<dynamic> placeOrder(Map body) async {
    final res = await http.post(Uri.parse('$baseUrl/api/menu/order'),
        headers: {'Content-Type':'application/json'}, body: jsonEncode(body));
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('Failed to place order');
  }

  Future<dynamic> addMenuItem(Map body) async {
    final res = await http.post(Uri.parse('$baseUrl/api/admin/menu'),
        headers: {'Content-Type':'application/json'}, body: jsonEncode(body));
    if (res.statusCode == 200) return jsonDecode(res.body);
    throw Exception('Failed to add item');
  }
}
