
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'dart:async';

class SocketService {
  late IO.Socket socket;
  final _menuController = StreamController.broadcast();
  final _orderController = StreamController.broadcast();

  Stream get menuStream => _menuController.stream;
  Stream get orderStream => _orderController.stream;

  void connect(String serverUrl) {
    socket = IO.io(serverUrl, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    });

    socket.on('connect', (_) {
      print('socket connected: ' + socket.id!);
    });

    socket.on('menu-updated', (data) {
      print('menu-updated event:');
      _menuController.add(data);
    });

    socket.on('new-order', (data) {
      print('new-order event:');
      _orderController.add(data);
    });
  }

  void disconnect() {
    try {
      socket.dispose();
    } catch (e) {}
  }

  void join(String room) {
    socket.emit('join', room);
  }
}
