
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class AdminDashboard extends StatefulWidget {
  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final api = ApiService('http://10.0.2.2:3000');
  final socket = SocketService();
  List items = [];
  final _name = TextEditingController();
  final _price = TextEditingController();

  @override
  void initState() {
    super.initState();
    socket.connect('http://10.0.2.2:3000');
    socket.orderStream.listen((data) {
      // show new order alert
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('New order received')));
    });
    _loadMenu();
  }

  void _loadMenu() async {
    try {
      final m = await api.fetchMenu();
      setState(() { items = m; });
    } catch (e) { print(e); }
  }

  void _addItem() async {
    final name = _name.text.trim();
    final price = double.tryParse(_price.text.trim()) ?? 0;
    final body = {'item': {'name': name, 'price': price}};
    await api.addMenuItem(body);
    _name.clear(); _price.clear();
    // backend will emit menu-updated and clients will refresh via socket
  }

  @override
  void dispose() {
    socket.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('KECGrub - Admin')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(children: [
          TextField(controller: _name, decoration: InputDecoration(labelText: 'Item name')),
          TextField(controller: _price, decoration: InputDecoration(labelText: 'Price')),
          SizedBox(height:8),
          ElevatedButton(onPressed: _addItem, child: Text('Add item')),
          Divider(),
          Expanded(child: ListView.builder(
            itemCount: items.length,
            itemBuilder: (_, i){
              final it = items[i];
              return ListTile(title: Text(it['name'] ?? ''), subtitle: Text('₹${it['price'] ?? 0}'));
            },
          ))
        ]),
      ),
    );
  }
}
