
import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/socket_service.dart';

class UserHome extends StatefulWidget {
  @override
  State<UserHome> createState() => _UserHomeState();
}

class _UserHomeState extends State<UserHome> {
  final api = ApiService('http://10.0.2.2:3000');
  final socket = SocketService();
  List items = [];

  @override
  void initState() {
    super.initState();
    socket.connect('http://10.0.2.2:3000');
    socket.menuStream.listen((data) {
      setState(() {
        items = data;
      });
    });
    _loadMenu();
  }

  void _loadMenu() async {
    try {
      final m = await api.fetchMenu();
      setState(() { items = m; });
    } catch (e) { print(e); }
  }

  void _placeOrder() async {
    if (items.isEmpty) return;
    final body = { 'items': [ { 'item': items[0]['_id'], 'qty': 1 } ], 'userId': null, 'total': items[0]['price'] };
    await api.placeOrder(body);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Order placed')));
  }

  @override
  void dispose() {
    socket.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('KECGrub - Menu')),
      body: Column(
        children: [
          Expanded(child: ListView.builder(
            itemCount: items.length,
            itemBuilder: (_, i) {
              final it = items[i];
              return ListTile(
                title: Text(it['name'] ?? 'No name'),
                subtitle: Text('₹${it['price'] ?? 0}'),
              );
            },
          )),
          Padding(
            padding: EdgeInsets.all(8),
            child: ElevatedButton(onPressed: _placeOrder, child: Text('Place sample order')),
          )
        ],
      ),
    );
  }
}
