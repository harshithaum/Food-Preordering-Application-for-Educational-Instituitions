
import 'package:flutter/material.dart';
import 'user_home.dart';
import 'admin_dashboard.dart';

class LoginPage extends StatefulWidget {
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  void _login() {
    final u = _userCtrl.text.trim();
    final p = _passCtrl.text.trim();
    if (u == 'admin' && p == 'admin') {
      Navigator.push(context, MaterialPageRoute(builder: (_) => AdminDashboard()));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => UserHome()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('KECGrub - Login')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: _userCtrl, decoration: InputDecoration(labelText: 'Username')),
          TextField(controller: _passCtrl, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
          SizedBox(height: 20),
          ElevatedButton(onPressed: _login, child: Text('Login'))
        ]),
      ),
    );
  }
}
