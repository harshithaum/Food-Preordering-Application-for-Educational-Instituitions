
# KECGrub Flutter App

Run on emulator (Android)
1. flutter pub get
2. flutter run

Notes: The app uses http to connect to backend at http://10.0.2.2:3000 by default (Android emulator). For physical device, replace with your machine IP.
