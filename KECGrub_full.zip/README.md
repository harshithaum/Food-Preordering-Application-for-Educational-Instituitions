
# KECGrub - Full Project (Realtime)

This archive contains a demo-ready backend (Node.js + Socket.IO) and Flutter frontend.
// See backend/README.md and frontend/README.md for details.
