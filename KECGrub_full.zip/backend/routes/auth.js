
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// register (convenience endpoint for demo)
router.post('/register', async (req, res) => {
  const { username, password, adminCode } = req.body;
  try {
    const exists = await User.findOne({ username });
    if (exists) return res.status(400).json({ msg: 'User exists' });

    const isAdmin = adminCode === process.env.ADMIN_SECRET;
    const salt = await bcrypt.genSalt(10);
    const hash = await bcrypt.hash(password, salt);

    const user = new User({ username, passwordHash: hash, isAdmin });
    await user.save();

    const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, process.env.JWT_SECRET);
    res.json({ token, user: { username: user.username, isAdmin: user.isAdmin } });
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

// login
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ msg: 'User not found' });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(400).json({ msg: 'Invalid credentials' });

    const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, process.env.JWT_SECRET);
    res.json({ token, user: { username: user.username, isAdmin: user.isAdmin } });
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

module.exports = router;
