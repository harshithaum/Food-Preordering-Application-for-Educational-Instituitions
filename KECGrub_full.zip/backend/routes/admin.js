
const express = require('express');
const router = express.Router();
const MenuItem = require('../models/MenuItem');

// add menu item
router.post('/menu', async (req, res) => {
  try {
    const { item } = req.body; // item = { name, price, ... }
    const newItem = new MenuItem(item);
    await newItem.save();

    // broadcast the change
    const io = req.app.get('io');
    io.emit('menu-updated', await MenuItem.find());

    res.json(newItem);
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

// update menu item
router.put('/menu/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await MenuItem.findByIdAndUpdate(id, req.body.item);
    const io = req.app.get('io');
    io.emit('menu-updated', await MenuItem.find());
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

// delete item
router.delete('/menu/:id', async (req, res) => {
  try {
    const id = req.params.id;
    await MenuItem.findByIdAndDelete(id);
    const io = req.app.get('io');
    io.emit('menu-updated', await MenuItem.find());
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

module.exports = router;
