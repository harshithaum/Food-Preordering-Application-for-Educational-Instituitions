
const express = require('express');
const router = express.Router();
const MenuItem = require('../models/MenuItem');
const Order = require('../models/Order');

// get menu
router.get('/', async (req, res) => {
  try {
    const items = await MenuItem.find();
    res.json(items);
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

// place order
router.post('/order', async (req, res) => {
  try {
    const { items, userId, total } = req.body;
    const order = new Order({ items, user: userId, total });
    await order.save();

    // populate for sending
    const populated = await order.populate('items.item').execPopulate?.() || order;

    const io = req.app.get('io');
    io.emit('new-order', populated);

    res.json(populated);
  } catch (err) {
    res.status(500).json({ err: err.message });
  }
});

module.exports = router;
