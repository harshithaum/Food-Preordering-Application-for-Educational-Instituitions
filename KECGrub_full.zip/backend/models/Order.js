
const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  items: [{ item: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem' }, qty: Number }],
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  total: Number,
  status: { type: String, default: 'pending' },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Order', OrderSchema);
