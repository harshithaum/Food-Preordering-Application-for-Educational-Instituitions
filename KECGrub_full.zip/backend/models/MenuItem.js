
const mongoose = require('mongoose');

const MenuItemSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, required: true },
  prepTime: { type: Number, default: 5 },
  available: { type: Boolean, default: true },
  description: { type: String, default: '' },
  imageUrl: { type: String, default: '' }
});

module.exports = mongoose.model('MenuItem', MenuItemSchema);
