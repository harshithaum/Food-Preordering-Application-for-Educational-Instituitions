
# KECGrub Backend

This is the Node.js + Express + Socket.IO backend for the KECGrub demo.

Instructions:
1. Copy `.env.example` to `.env` and set MONGO_URI and JWT_SECRET.
2. `npm install`
3. `npm run dev` (requires nodemon) or `npm start`

Endpoints:
- POST /api/auth/register
- POST /api/auth/login
- GET  /api/menu
- POST /api/menu/order
- POST /api/admin/menu
